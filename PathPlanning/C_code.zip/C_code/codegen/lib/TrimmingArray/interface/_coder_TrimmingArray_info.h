/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: _coder_TrimmingArray_info.h
 *
 * MATLAB Coder version            : 5.0
 * C/C++ source code generated on  : 11-May-2020 13:35:47
 */

#ifndef _CODER_TRIMMINGARRAY_INFO_H
#define _CODER_TRIMMINGARRAY_INFO_H

/* Include Files */
#include "mex.h"

/* Function Declarations */
MEXFUNCTION_LINKAGE mxArray *emlrtMexFcnProperties(void);

#endif

/*
 * File trailer for _coder_TrimmingArray_info.h
 *
 * [EOF]
 */
