/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: _coder_TrimmingArray_info.c
 *
 * MATLAB Coder version            : 5.0
 * C/C++ source code generated on  : 11-May-2020 13:35:47
 */

/* Include Files */
#include "_coder_TrimmingArray_info.h"
#include "emlrt.h"
#include "tmwtypes.h"

/* Function Declarations */
static const mxArray *emlrtMexFcnResolvedFunctionsInfo(void);

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : const mxArray *
 */
static const mxArray *emlrtMexFcnResolvedFunctionsInfo(void)
{
  const mxArray *nameCaptureInfo;
  const char * data[38] = {
    "789ced5d5b6c235999766f77c37019661901c345d0f4c04aa091da76da7612de7cb7e3f8163b4e9c01e272b96c575cb754951d3be2625e462b81b42bad562bad"
    "34acb4085856088df669d1226d844042231e609a41f3c003082190766747425ac4201e28bbea642ad5ae29dba77ce23a7d7ea9dba9fedbe7fbffffd4f9eacf5f",
    "e7e2bb91cddff0f97ceff2e9d2fdd28de9e7e3da9f07da8f7f6dfcfb5ff9ae8a557fc3f84c5aae81dcf6ddf2bdfe45fd7b40ff92f6d7df19d7b428a8cc50d52f"
    "048a672ebfd9127956a004b53a92189fcc282237605a534d9be5982acb3315f3456172c5a74caacb8b896af273bccbd0bd4a9ff7c95de50d0b39f3c5653cfed3",
    "e4ef9fbef886bfb766c4c3ac07feef9bae277a2093ff37891fd03f9bfc4cfc53fe7d859115bf2c3645d59f10e93ecf08aae2cf47abbbd1987f23b01138ded374"
    "5599a2197f8952bb258e120456e8f8e3c7b4d862fc5599e5b56875a2b24c8deef1861f131c09d28fb739f801f4b286af289a09a6384ef40d48fcb7d8e2bf65da",
    "7e4bec3739e60dbc1720f18a0efe02fdb3d9ddc369d79564b12353fc472737d86597ed4dfa8cf2aba2c835c5a19fe1393fc736fd3ca57254d3dfa254aadd17fc"
    "9731d37acc295e4fcc69bff9d36cffe3bec7a6e3b0f0d597a7ff6516deeb0e78af2f81377ec77fbf07251e90ebc21bdab437ebfe9b85f73e1b3c70ff017deeb4",
    "1c54cfce0eab3d311816ba47c374b8aba4dfb0a3e480e36487cf74fda7197eaeba7df3385e268ed73d8e61ef83f73bd80ff413fa97efb1da43541628ee9e40c9"
    "1d56a0bb3da7fbdfc90eabd8d90104e05d40fadd305dcfc203fa85fa4de95232d3f24f6365fc3de9c667f41f9f01d1f35f46ef1e8f8a3fdef9cacf90f2b1efb5",
    "5016299e21b8f37167ab1cdb6e07b70ad14cad7954489f529b1be7317cf8f8c2e6fbb88deb79fdb96debcfed69fb6d4e14659ff37d3f2f1e4c1ebc0c5ed6164f"
    "6f1fe8619e9f0c37797a4e2335fd9dc53747bcdce2897bbf46cbbb63ee3919251e10dc79f73c1f1cc469ba9be6f6995a920f844a112942f2e0b519c76348fbef",
    "38d80ff4963c9855627d9653b342a1cf33324b5f1b0fff0812af63ba9ee53fd0afe4b9698da24d9d6225fcfc2dc4fcfcf60f7e0f251e10ecf93920b139254917"
    "132536d50d57b7a2cd703149f819177efe9083fd406fe16785a6384abe07b264f83cd92a76f6000178e63aff32fecf5de75fb4ff267f1e22e467f4b899fa12db",
    "7cf937bf1750e201c19d8f6bc5d3445f8eed26a242e4b4bec50ce2c5f608a33a85d7f9f8ef21edffa483fd406fe1634a92b851654a2ea9be40abac2864851247"
    "d1e07decacf789cbd8f784e97a967d40df36ac38ee52424b4ba8ddcaa79b0ef840ef0e5fdb8715743c2abef9f203c475e67ee68f48f10cc19dbf23bd70efa072",
    "d8129adcd1f68ea81cd54b3116a37ac7a336bee7f5eb315bbf1e9bb6cf2a8a44c90ae3d57a73c1164f6f1fe8619ebb93084d9ebc2056933e42c5173f7e1131ff"
    "323f7e05299e21b8f3ef695cdc2b459a81bdad4c7eaf15e8d636fb5c3541f877ddf9770ce9d7bad43996e56752e778f893d439f0e56952e778f3f6af7b7e5c03",
    "d27ee77c58334266875ecd87776df1f4f6811eae0ea5fde00791d29f98a878e1bbdf46ccb32ffec35751e201c19d67879d41b254af97cee24ab396698a3cb3dd"
    "2c109e7d847896d41d48dd81d41d48dd01ae7daff32cec7df05e07fb81de525fe018a1a3767df07505abd8d90164edf977665d410f174afefdafea4b68f3dca7",
    "7ff1024a3c205ee5df79c75d75b776b4cdb70ee5e841687318bc5fe303859c8ff0efbaf0efdf42daff3107fb81dec2bfb428286a41142a9a351ca38a4282e5af"
    "c4b50169d7a2f9f00524dea71de200f4eef0f1acf0a1ad4320aff73ef97109251e10aff2f3bcf9315b0dd54ba9fddaf0285595e5fbb18d7436924be1c3cf1736",
    "dfc76d5c93ba842ea42ee12e1ea94be842ea128bb5eff5bc5882b47fdefd7f58c579ff1f2ff02ecafeba8c19c2757564ff9fd5e2a1aa47649561a2707f23c66f"
    "6795e840e673c55369e823bcbb2ee398ecffb39cdf0dd3f52c3ca0bfee7d42c8fe3f73e219e2553e26fbffe0c1c70d48fb49bd4117526f980f8fd41b7421f586",
    "c5da273c6b67ff25cfaab206e9559ecddbe2e9ed033d14cfaa8066a7a1c27afd84efe61d05299e21b8f32c9fcf1f86c5d38e2a6686bd6135b65dcef632197c78"
    "16763dd4814dfb208e403f19c771e8f76996dd105cac33cc7b3f58ea0cd37dc158c1bd3aef5b6ded78ebb4fdbed013c433c1b53ac3671dfc06fa85fa6fde3a83",
    "113d94f92ff23ac3f76f6690e219e2555e9eb7ee9bc81c9e0f0727b1787e18dccc86cbfcd9d976cf477879dd78790ce9c7471cfc007a0b2f275885d2f2d584a8"
    "96342aba467ef6563f5ac286f07ddcf76f209e7ff683ddf7a1c403e2555e9e373f6af7b642677c763b344864227baa1208d6c212997f76d9fe914dfb208e40ef",
    "ce78a6045118f1625f39060cedf67e104bf2b3755b33c2cf90cf59bbb8b9c52717bf44cccf9f7bfa2b28f180e0cecf11391167b65a95cd687cbf9c2ab5b49fcf"
    "37e3f8f0b3d7ebc6b0eb37ee3ad80ff4d67d2f1f7a5058e22a41da05bbdfe50524feba3d771b36f6bac52fafbd8c98afcb3ffd264a3c20b8f3f5e65e38c0f7d8",
    "622d462b74b2598da7846c17a3fab3d7f91a152f5e62e734866138cfaeab5ba4de5c82ed3049660794caf82dc143596f26f38c578b876c1fb5a3da70ff60543f"
    "6feeee250ef72a9da6dcdcc168bec585cdf7bd3aae61ef8b271dfc01fa01c5b19a590ca5aa32dbecab8c7235ae0d483b6e99aeafda716bda3ecd709c196f6df7",
    "b734752347091dffc381433a3fe3c55f3e40cacbbe279e7e0a299e21b8f3f27621132ab7daaa2ad6fa03261a2f0a854c8cf0f2daf27203d21f322f4e17322f6e"
    "3e3c322f4e17322f6eb1f67f62f3fd79e37862d33e8823d0af9677ef52b24c8d2a67ac4a77affad780f4cfe9dc67561128c1453c3ccf7dd6f71dd62285fcdce7",
    "3f9c22ae4bfce8d50b94784070e7e1b38360b82ed7e2c9a35026dfdd2c94ead93d16a3f9165e1fc76348fbef38d80ff4e4dc6772ee330c1e39f7591772eef362"
    "ed5fd87cdfabf58931a43f1f70f007e86991e3284961b2822aee8a1d96a6b8b8c8f579ebbc8b06a43d4ef3e1381ddb35beee3af80ff4aef6a76d30d1ed5f41de",
    "f3ad160f155f77d3a9dcf67eac92a106743ad83bcd95121b343957d4b3e3dbbdba323d45bc2e5e86fd3d08e5394ab4d13793f650f105f273949e6f3e8f120f08"
    "eefc9ba22b61aa7f1648874bb4bc9fdda53668ba4fea196b3f8ed7f5bc3a9c79969c57477876599ec5fdbc3a92e7cef6eba6ad5f37a7edf3d4f04a1c61efc7a7",
    "1ce208f4d6fab5d062865a183cf51e0074a71643e4eff3de9d405b7ff0fd7ff24348f10cf12a2fcfbbafc5613f13de68c5efc736ca0c9d4fe7eb5b81b4f95c33"
    "aff3b2d7c731d9cf7839bf1ba6eb5978404ff6335e92afc87ec65321fb192fd6fea3cec74be6a73c2b14e5bc962b235be7a1519dd96fd87e2b99ae67f90df4ee",
    "9c8305c2858e7f5f6710e7c35fff4614299e21b8f3ef39757044a787d99dfba74c4409b1e5936da68bd1fc09af8f63920f937cd8fa49f2617cf918f77cf8c2e6"
    "fbf3c6b16ed33e8823d0bbcdc777b5e498e5fbfc86c59f31a43f1f76f007e82dfcdc64358e19e541968c703db4254f865d0f5d73f01fe8dde9cfab6143b94fc5",
    "ef51e7cb795e428a6708eefc4cb77b996a4529460ea8547f97cdf24274278751be8ccb78267933c99bad9f246fc6979771cf9b71e1e506a41f8b9e8f87cbfc8a"
    "82831d404fcecd9b0f8f9c9ba70b39376fb1f671e161d87d903fe1e007d05bf74196246e149b5a55a1298e9253c6febdc02e09d22ed87d9061e735520ef840ef",
    "4effda8613f9fc38d4fb0e8d9ffc38a96ff8dce7ef4a2142e7cf3986928fca42a2cf6594c3708caccf5bfbf10dcbe71f73f00be8ad7c3e10d95674b209528aa3"
    "54951158a173c5aec6927659c5ce2e206ed53f3eed8007f42ef5ef8cf0a15d6ff295773f409b778f7ffb67a47886e0cedbe73b99fbf17de9902f378bade8613b",
    "931ff245b25fdc65fb3d9bf6411c817e3579f75d65cade31eb5bbbf5ddc7685dea26647fa325f371b2bfd14af1c8fe46eeb40f5b1745793e89cc3f7c3e4903d2"
    "7ea7f5824a9fbf122f583c1cf7f904fda3c50afbba87efe7af9e22c53304779edda0e8044b850b9138df579bf941743b5ad8c3e8fda1d7c73199cfb19cdf0dd3",
    "3599cfb102be22f339a642e6732cd6bed7f9b80169ffa2f33860f150ef5344e66bb88b47e66be842e66b2cd6bed77916d57d20c922cd28cab16683f663eb9815"
    "a4beaa5cdfba12d8ba2fe3e037d0bbbabfd4ec20223dffe9139f47bcce64f8edef20c53304775e3ec966ca543f5cd8e29b817ae5a4192a96e229320f63edc737",
    "a953903a85f593d429f0e569dceb14b8f2f418d2af0f3af805f40fcdb7a831b42aca0996bf1ae706a43d8bbed7839dc75e71f01fe8dd994f630adbbdf9de87ba"
    "c52bfffb3f88e751fcea5fbf80120f08ee3c1dda39a84b02174a1feded662ba3da7ebd5fa9c6f1e1695cc6f335e5cfac526586ea9e78765d7c7c0189d7305d23",
    "cf9f2fa3872e7f463eefe25bdf9390e219823b2f5383ddcd9341f2a85b16ea87a954519473a52646f3db2e6cbe8fdbb876f1bd9f2ab342c7abf3ddf2b6787afb"
    "400ff5de4f05affda6a1425a5f46cebb37ef2848f10cc19d77f97cfe302c9e76543133ec0dabb1ed72b697c168bd08a95bccf66bc9fde628456164b546716c4b",
    "2f5d78b56e8176fdfdd5b0a19c9ff12aeabac528f50d94784070e7e9fee1c66e9ccaeff14707756e7f54ab70653589114fe3329ec7907edc71f003e8e75dbfd7"
    "80b467515e26ebf496cca7c93abd95e291757aeeb48f0b4f3720fdb86debc7ed69fb6d4e1465dff5e5c7b0f50b14f31d196ef24bcf3452d8afd71b73cf5d99d7",
    "b86a3c20d8f36d3e3888d37437cded33b5241f0895225204a3f971846f7571e23fcd84e991aad7354f19966f776cf1f4f681de85f3aca79102848b8a1f5e7b19"
    "31df967ffa4d94784070e7db502a921db5c5513e5d0b9e7587acc08b7c1ea3fcd60b79d32ad7e339ad8f334ad2d7c6b3289f87aed5f38da0a1acfb7e12f5fa8f",
    "8f7ee916523c43bccab7f39e531da92ad5149fee8faafb4d35966ca6bbc1b6f9bd8bd7f91697f14cd67b2ce777c3744dd67bac80b7c87a8fa990f51e8bb58f0b"
    "2f8f21fdb8e3e007d0a37a1fb7e8fe15e47d1c791ff728f334791ff7e6edaf0b4f93fd2d96c35bd7f989767124fb5bcc896708eefc8cfbfe16849f7599b7de45",
    "8b7c9315187d59609263784698d0f3a51d12a41dd77d2e54cb011fe85dedcf9941457bbe086abe1efff087ff82120f08ee7ccd478a85be10c9940ea8fc666ea8"
    "2473db290aa3f5d38fdaf876abeec02acc69df5477b86e9e7e01123fe7800ff42eccc7d02387783f8b7ffc0fc475e8d0879348f10cc19d8fc55c6f37729fa315",
    "7a14dda14f9261b19e3bc4685d88d7c7312c0f9aaf67d90ff49a49c78605c7b42833ebc2c31790f89f71c0077aa8e7a9de81e0696a0d25d2bac6776e23ae6b5c"
    "a8645eb2cf7d5e6e7536f381965292f70fd2fb9bfcb618e0fa218cf2e40b9bef7b755c93f91bcbf9dd305d93f91b2be02f327f632a64fec662ede35ac720e75b",
    "bbc3dbe47cebd5e291f3ad7521e75b2fd63eaebcdd80f48b9c13a50b39276a3e3c724e942ee49ca8c5da7fc5e6fbf3c6b16fd33e8823d0a3e0dfbbb4c8e5a913"
    "519e245d592d15f3b977bf3ce5e027d05bf2e8c9b412853d675c7b2e2c3adfee0212ef5907bf811eb6def1500a0d2287f83de1cf10d7a3c7d977fc0d4a3c20b8",
    "f3f676f2f420b89be88d92b4d8cfe6e94af03cd5c2689edda3c2db63483f3fe2e027d04f8be5827adc16654e14a56371c0c86d4e3c3ba6bb0cddf36edda361ba"
    "76ad5e6d7deda09741de247ee8ead5ff7eff25b4fcfdec0f2a28f180e0cedf4a2e394c26cecf4b3bc38d507e23102f4783018cd6b1fccee6fbf3c6f1399bf641",
    "1c817ed5e3faee9bff87e32ec34913424795ffb24a9b35c7f99af27e566831c3aca05edaf16f9076a41cec00faa5fabbcd0e9996246ad6fb27f1435927f9a7af"
    "a1de97ee5d9f4289070477be0e4ad5a38c40870a43e164900a1492727a98c688afbd3a7e2548bb1f77b01be85945d0d72cab2389f1a1e37bb7f7a52b3af80bf4",
    "f0fd648a17c275dea8f9d6f7e0bb79a47886e0ceb7b9704e2a0533bd56b7c39c66a8b3cdb2ca8752f8f02dc98f97f39bec1baa0bd937743e3cb26fa82e64dfd0"
    "c5da27fcbc3a7e6605c2cff3f1332b107e76170f08eefc5c296d9cf0b1e428dd8a97a90326afd64e8afb18bd1f5cebdf832daf07659e6715459f22eb56dde26d",
    "0ef6033dabd00cc729faa2301f3a9e77fbfc1224f3e9c0f9ab46c850d689bffc3cdaf77abe7ffebf34523c4370e7dd033e3b481dd6bbe20955ef34e31d297124"
    "07309a4fe7f5714cd6052ee777c3744dd605ae80afc8bac0a9907581f3b5ff1787c178df",
    "" };

  nameCaptureInfo = NULL;
  emlrtNameCaptureMxArrayR2016a(&data[0], 98688U, &nameCaptureInfo);
  return nameCaptureInfo;
}

/*
 * Arguments    : void
 * Return Type  : mxArray *
 */
mxArray *emlrtMexFcnProperties(void)
{
  mxArray *xResult;
  mxArray *xEntryPoints;
  const char * epFieldName[6] = { "Name", "NumberOfInputs", "NumberOfOutputs",
    "ConstantInputs", "FullPath", "TimeStamp" };

  mxArray *xInputs;
  const char * propFieldName[4] = { "Version", "ResolvedFunctions",
    "EntryPoints", "CoverageInfo" };

  xEntryPoints = emlrtCreateStructMatrix(1, 1, 6, epFieldName);
  xInputs = emlrtCreateLogicalMatrix(1, 1);
  emlrtSetField(xEntryPoints, 0, "Name", emlrtMxCreateString("TrimmingArray"));
  emlrtSetField(xEntryPoints, 0, "NumberOfInputs", emlrtMxCreateDoubleScalar(1.0));
  emlrtSetField(xEntryPoints, 0, "NumberOfOutputs", emlrtMxCreateDoubleScalar
                (1.0));
  emlrtSetField(xEntryPoints, 0, "ConstantInputs", xInputs);
  emlrtSetField(xEntryPoints, 0, "FullPath", emlrtMxCreateString(
    "C:\\Users\\robot\\Documents\\MATLAB\\2020_RoboTrace\\PathPlanning\\C_code\\TrimmingArray.m"));
  emlrtSetField(xEntryPoints, 0, "TimeStamp", emlrtMxCreateDoubleScalar
                (737921.74336805556));
  xResult = emlrtCreateStructMatrix(1, 1, 4, propFieldName);
  emlrtSetField(xResult, 0, "Version", emlrtMxCreateString(
    "9.8.0.1323502 (R2020a)"));
  emlrtSetField(xResult, 0, "ResolvedFunctions", (mxArray *)
                emlrtMexFcnResolvedFunctionsInfo());
  emlrtSetField(xResult, 0, "EntryPoints", xEntryPoints);
  return xResult;
}

/*
 * File trailer for _coder_TrimmingArray_info.c
 *
 * [EOF]
 */
