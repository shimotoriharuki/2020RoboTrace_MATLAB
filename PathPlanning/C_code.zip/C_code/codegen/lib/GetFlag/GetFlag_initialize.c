/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: GetFlag_initialize.c
 *
 * MATLAB Coder version            : 5.0
 * C/C++ source code generated on  : 28-May-2020 20:26:43
 */

/* Include Files */
#include "GetFlag_initialize.h"
#include "GetFlag.h"
#include "GetFlag_data.h"
#include "rt_nonfinite.h"

/* Function Definitions */

/*
 * Arguments    : void
 * Return Type  : void
 */
void GetFlag_initialize(void)
{
  rt_InitInfAndNaN();
  isInitialized_GetFlag = true;
}

/*
 * File trailer for GetFlag_initialize.c
 *
 * [EOF]
 */
