/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: GetFlag_data.h
 *
 * MATLAB Coder version            : 5.0
 * C/C++ source code generated on  : 28-May-2020 20:26:43
 */

#ifndef GETFLAG_DATA_H
#define GETFLAG_DATA_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "GetFlag_types.h"

/* Variable Declarations */
extern bool isInitialized_GetFlag;

#endif

/*
 * File trailer for GetFlag_data.h
 *
 * [EOF]
 */
