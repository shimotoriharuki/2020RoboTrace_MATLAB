/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: GetFlag_data.c
 *
 * MATLAB Coder version            : 5.0
 * C/C++ source code generated on  : 28-May-2020 20:26:43
 */

/* Include Files */
#include "GetFlag_data.h"
#include "GetFlag.h"
#include "rt_nonfinite.h"

/* Variable Definitions */
bool isInitialized_GetFlag = false;

/*
 * File trailer for GetFlag_data.c
 *
 * [EOF]
 */
