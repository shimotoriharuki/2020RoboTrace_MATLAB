/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: GetFlag_initialize.h
 *
 * MATLAB Coder version            : 5.0
 * C/C++ source code generated on  : 28-May-2020 20:26:43
 */

#ifndef GETFLAG_INITIALIZE_H
#define GETFLAG_INITIALIZE_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "GetFlag_types.h"

/* Function Declarations */
extern void GetFlag_initialize(void);

#endif

/*
 * File trailer for GetFlag_initialize.h
 *
 * [EOF]
 */
