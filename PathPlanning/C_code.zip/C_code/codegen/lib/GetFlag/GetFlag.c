/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: GetFlag.c
 *
 * MATLAB Coder version            : 5.0
 * C/C++ source code generated on  : 28-May-2020 20:26:43
 */

/* Include Files */
#include "GetFlag.h"
#include "GetFlag_data.h"
#include "GetFlag_emxutil.h"
#include "GetFlag_initialize.h"
#include "median.h"
#include "rt_nonfinite.h"
#include <math.h>

/* Function Definitions */

/*
 * Arguments    : const double position[2000]
 *                double searchRange
 *                double num
 *                emxArray_real_T *flag
 * Return Type  : void
 */
void GetFlag(const double position[2000], double searchRange, double num,
             emxArray_real_T *flag)
{
  emxArray_real_T *storePosition;
  int k;
  int i;
  int nx;
  emxArray_boolean_T *Outlier;
  emxArray_real_T *temp;
  emxArray_real_T *y;
  emxArray_real_T *x;
  int b_i;
  unsigned int cnt;
  double diff_idx_0;
  double diff_idx_1;
  double lb;
  if (!isInitialized_GetFlag) {
    GetFlag_initialize();
  }

  emxInit_real_T(&storePosition, 2);

  /* GetFlag.m */
  k = flag->size[0] * flag->size[1];
  flag->size[0] = 1;
  i = (int)num;
  flag->size[1] = i;
  emxEnsureCapacity_real_T(flag, k);
  k = storePosition->size[0] * storePosition->size[1];
  storePosition->size[0] = i;
  storePosition->size[1] = 2;
  emxEnsureCapacity_real_T(storePosition, k);
  nx = i << 1;
  for (k = 0; k < nx; k++) {
    storePosition->data[k] = rtNaN;
  }

  emxInit_boolean_T(&Outlier, 2);
  emxInit_real_T(&temp, 2);
  emxInit_real_T(&y, 2);
  emxInit_real_T(&x, 2);
  for (b_i = 0; b_i < i; b_i++) {
    storePosition->data[b_i] = position[b_i];
    storePosition->data[b_i + storePosition->size[0]] = position[b_i + 1000];
    k = temp->size[0] * temp->size[1];
    temp->size[0] = 1;
    temp->size[1] = storePosition->size[0] << 1;
    emxEnsureCapacity_real_T(temp, k);
    nx = storePosition->size[0] << 1;
    for (k = 0; k < nx; k++) {
      temp->data[k] = rtNaN;
    }

    cnt = 1U;
    k = storePosition->size[0] - 1;
    for (nx = 0; nx <= k; nx++) {
      diff_idx_0 = storePosition->data[b_i] - storePosition->data[nx];
      diff_idx_1 = storePosition->data[b_i + storePosition->size[0]] -
        storePosition->data[nx + storePosition->size[0]];
      if (sqrt(diff_idx_0 * diff_idx_0 + diff_idx_1 * diff_idx_1) <= searchRange)
      {
        temp->data[(int)cnt - 1] = (double)nx + 1.0;
        cnt++;
      }
    }

    diff_idx_0 = median(temp);
    k = x->size[0] * x->size[1];
    x->size[0] = 1;
    x->size[1] = temp->size[1];
    emxEnsureCapacity_real_T(x, k);
    nx = temp->size[0] * temp->size[1];
    for (k = 0; k < nx; k++) {
      x->data[k] = temp->data[k] - diff_idx_0;
    }

    nx = x->size[1];
    k = y->size[0] * y->size[1];
    y->size[0] = 1;
    y->size[1] = x->size[1];
    emxEnsureCapacity_real_T(y, k);
    for (k = 0; k < nx; k++) {
      y->data[k] = fabs(x->data[k]);
    }

    diff_idx_1 = 1.4826022185056018 * median(y);
    lb = diff_idx_0 - 3.0 * diff_idx_1;
    diff_idx_0 += 3.0 * diff_idx_1;
    k = Outlier->size[0] * Outlier->size[1];
    Outlier->size[0] = 1;
    Outlier->size[1] = temp->size[1];
    emxEnsureCapacity_boolean_T(Outlier, k);
    nx = temp->size[0] * temp->size[1];
    for (k = 0; k < nx; k++) {
      diff_idx_1 = temp->data[k];
      Outlier->data[k] = ((diff_idx_1 < lb) || (diff_idx_1 > diff_idx_0));
    }

    /*  �O��l�����m���� */
    nx = Outlier->size[1];
    if (Outlier->size[1] == 0) {
      diff_idx_0 = 0.0;
    } else {
      diff_idx_0 = Outlier->data[0];
      for (k = 2; k <= nx; k++) {
        diff_idx_0 += (double)Outlier->data[k - 1];
      }
    }

    /* ���ׂđ��� */
    flag->data[b_i] = (diff_idx_0 >= 1.0);

    /*  1�ȏゾ������������Ă��� */
  }

  emxFree_real_T(&x);
  emxFree_real_T(&y);
  emxFree_real_T(&temp);
  emxFree_boolean_T(&Outlier);
  emxFree_real_T(&storePosition);
}

/*
 * File trailer for GetFlag.c
 *
 * [EOF]
 */
