#ifndef PORTABLE_WORDSIZES
#ifdef __MW_TARGET_USE_HARDWARE_RESOURCES_H__
#ifndef __MW_TARGET_HARDWARE_RESOURCES_H__
#define __MW_TARGET_HARDWARE_RESOURCES_H__

#include "arm_cortex_m_wrapper.h"


#endif /* __MW_TARGET_HARDWARE_RESOURCES_H__ */

#endif

#endif
