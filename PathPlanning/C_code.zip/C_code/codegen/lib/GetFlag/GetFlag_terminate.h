/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 * File: GetFlag_terminate.h
 *
 * MATLAB Coder version            : 5.0
 * C/C++ source code generated on  : 28-May-2020 20:26:43
 */

#ifndef GETFLAG_TERMINATE_H
#define GETFLAG_TERMINATE_H

/* Include Files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "GetFlag_types.h"

/* Function Declarations */
extern void GetFlag_terminate(void);

#endif

/*
 * File trailer for GetFlag_terminate.h
 *
 * [EOF]
 */
