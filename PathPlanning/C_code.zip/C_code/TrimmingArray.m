function TrimmedData = TrimmingArray(Data)
    TrimmedData = rmmissing(Data); %NuNを削除
end